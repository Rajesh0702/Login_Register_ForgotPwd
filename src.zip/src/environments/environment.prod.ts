export const environment = {
  production: false,
  version: "4.2.1",
};
